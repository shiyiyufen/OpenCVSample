//
//  ViewController.m
//  WantedProj
//
//  Created by JD_Acorld on 14-8-2.
//  Copyright (c) 2014年 hxy. All rights reserved.
//

#import "ViewController.h"
#import "HuntViewController.h"
#import <QuartzCore/QuartzCore.h>
@interface ViewController ()

@end

@implementation ViewController

@synthesize photoCamera;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.huntBtn.layer.masksToBounds = YES;
    self.huntBtn.layer.cornerRadius = 5.0f;
    
    // Initialize camera
    photoCamera = [[CvPhotoCamera alloc]
                   initWithParentView:_adImageView];
    photoCamera.imageWidth = _adImageView.frame.size.width;
    photoCamera.imageHeight = _adImageView.frame.size.height;
    photoCamera.delegate = self;
    photoCamera.defaultAVCaptureDevicePosition =
    AVCaptureDevicePositionBack;
    photoCamera.defaultAVCaptureSessionPreset =
    AVCaptureSessionPresetPhoto;
    photoCamera.defaultAVCaptureVideoOrientation =
    AVCaptureVideoOrientationPortrait;
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.view.frame];
    imageView.tag = 10;
    imageView.image = [UIImage imageNamed:@"ad.png"];
    [self.view addSubview:imageView];
    
    [self.huntBtn.superview bringSubviewToFront:self.huntBtn];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
//    [self skipToNextPageWithImage:nil];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (UIView *)adsView
{
    return [self.view viewWithTag:10];
}

- (IBAction)switchCamera:(id)sender
{
    if (photoCamera.defaultAVCaptureDevicePosition == AVCaptureDevicePositionBack) {
        photoCamera.defaultAVCaptureDevicePosition = AVCaptureDevicePositionFront;
    }else photoCamera.defaultAVCaptureDevicePosition = AVCaptureDevicePositionBack;
}

- (IBAction)huntNow:(UIButton *)sender
{
    if (sender.isSelected)
    {
        [photoCamera takePicture];
    }else
    {
        _adImageView.hidden = NO;
        [[self adsView].superview sendSubviewToBack:[self adsView]];
        [photoCamera start];
        [sender setSelected:YES];
    }
}

- (void)photoCamera:(CvPhotoCamera*)camera
      capturedImage:(UIImage *)image;
{
    [camera stop];
    [self skipToNextPageWithImage:image];
}

- (void)photoCameraCancel:(CvPhotoCamera*)camera;
{
    
}

- (void)skipToNextPageWithImage:(UIImage *)image
{
    HuntViewController *hunt = [[HuntViewController alloc] init];
    hunt.image = image;
    [self.navigationController pushViewController:hunt animated:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    _adImageView.hidden = YES;
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [photoCamera stop];
    self.huntBtn.selected = NO;
}

- (void)dealloc
{
    photoCamera.delegate = nil;
}
@end
